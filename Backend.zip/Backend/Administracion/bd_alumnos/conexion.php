<?php

    $usuario = "root";
    $contraseña = "101001";

    $conexion = new PDO('mysql:host=localhost;dbname=escuela', $usuario, $contraseña);
?>