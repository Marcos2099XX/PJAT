<?php require_once "vistas/superior.php" ?>

    <!-- Inicio del contenido -->
        <div class="d-flex flex-column justify-content-center align-items-center">

            <div>
                <br>
                <br>
                <h1>Bienvenido al panel de control escolar</h1>
            </div>

            <div class=""> 
                <br>
                <br>           
                <img src="logoEscuela.jpeg" alt="">
            </div>    
 
           
        </div>

    <!-- Fin del contenido -->

<?php require_once "vistas/inferior.php" ?>