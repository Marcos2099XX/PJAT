<?php

    $usuario = "epiz_33142435";
    $contraseña = "KvOTNgOjH2Qnw";

    $conexion = new PDO('mysql:host=sql306.epizy.com;dbname=epiz_33142435_escuela', $usuario, $contraseña);
?>